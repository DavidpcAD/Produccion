var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0rlb~6b._.js")
R.c("server/chunks/[root-of-the-server]__13w9q_n._.js")
R.m(62395)
module.exports=R.m(62395).exports
