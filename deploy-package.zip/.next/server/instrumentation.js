var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/_00bl_j0._.js")
R.m(69449)
module.exports=R.m(69449).exports
