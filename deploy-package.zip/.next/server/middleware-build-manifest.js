globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/r-hS5RZJ_YMGw7yLZvjar/_buildManifest.js",
    "static/r-hS5RZJ_YMGw7yLZvjar/_ssgManifest.js",
    "static/r-hS5RZJ_YMGw7yLZvjar/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/04ltku1u2mhd1.js",
    "static/chunks/06yalz1u_k_~7.js",
    "static/chunks/0yre8_-puwewa.js",
    "static/chunks/14ycw-1vs7o6q.js",
    "static/chunks/turbopack-149vrd10bdd1-.js"
  ]
};
