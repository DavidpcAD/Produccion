1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0h.oi097.lnwu.js","/_next/static/chunks/0awi1pd.z_que.js","/_next/static/chunks/14d95v2q-d4b-.js"],"default"]
3:I[37457,["/_next/static/chunks/0h.oi097.lnwu.js","/_next/static/chunks/0awi1pd.z_que.js","/_next/static/chunks/14d95v2q-d4b-.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"r-hS5RZJ_YMGw7yLZvjar"}
