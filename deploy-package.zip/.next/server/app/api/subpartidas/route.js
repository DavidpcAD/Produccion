var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/subpartidas/route.js")
R.c("server/chunks/[root-of-the-server]__12kx9rc._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_subpartidas_route_actions_053le56.js")
R.m(71738)
module.exports=R.m(71738).exports
