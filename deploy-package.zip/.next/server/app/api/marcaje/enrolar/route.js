var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/marcaje/enrolar/route.js")
R.c("server/chunks/[root-of-the-server]__0agwfhe._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_marcaje_enrolar_route_actions_0x06mb7.js")
R.m(70278)
module.exports=R.m(70278).exports
