var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/marcaje/colaboradores/route.js")
R.c("server/chunks/[root-of-the-server]__09c.aa4._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_marcaje_colaboradores_route_actions_055fr1-.js")
R.m(1045)
module.exports=R.m(1045).exports
