var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bc/inventory-groups/route.js")
R.c("server/chunks/[root-of-the-server]__0ja9esw._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_bc_inventory-groups_route_actions_0_8pw7m.js")
R.m(45222)
module.exports=R.m(45222).exports
