var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bc/jobs/route.js")
R.c("server/chunks/[root-of-the-server]__0m~cbvz._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_bc_jobs_route_actions_11sfmnw.js")
R.m(60233)
module.exports=R.m(60233).exports
