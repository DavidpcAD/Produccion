var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bc/dimensions/route.js")
R.c("server/chunks/[root-of-the-server]__044gmq4._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_bc_dimensions_route_actions_0weorek.js")
R.m(71868)
module.exports=R.m(71868).exports
