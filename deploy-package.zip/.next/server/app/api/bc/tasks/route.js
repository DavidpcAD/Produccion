var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bc/tasks/route.js")
R.c("server/chunks/[root-of-the-server]__0f2f.w.._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_bc_tasks_route_actions_0ljhwmm.js")
R.m(10474)
module.exports=R.m(10474).exports
