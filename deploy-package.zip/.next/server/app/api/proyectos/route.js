var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/proyectos/route.js")
R.c("server/chunks/[root-of-the-server]__13po7ln._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_proyectos_route_actions_0.1t~f8.js")
R.m(23472)
module.exports=R.m(23472).exports
