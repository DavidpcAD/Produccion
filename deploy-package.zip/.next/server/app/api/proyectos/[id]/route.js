var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proyectos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0iurdqx._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_proyectos_[id]_route_actions_0g7m6p3.js")
R.m(25917)
module.exports=R.m(25917).exports
