var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proyectos/[id]/asignaciones/route.js")
R.c("server/chunks/[root-of-the-server]__0-lfi50._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_proyectos_[id]_asignaciones_route_actions_0y1zq0..js")
R.m(77200)
module.exports=R.m(77200).exports
