var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/usuarios/[id]/roles/route.js")
R.c("server/chunks/[root-of-the-server]__0ad4o3v._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_usuarios_[id]_roles_route_actions_0oyapy3.js")
R.m(70558)
module.exports=R.m(70558).exports
