var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/usuarios/[id]/marcaje/route.js")
R.c("server/chunks/[root-of-the-server]__0gbmbi~._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_usuarios_[id]_marcaje_route_actions_0nm652c.js")
R.m(6894)
module.exports=R.m(6894).exports
