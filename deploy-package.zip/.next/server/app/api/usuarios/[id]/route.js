var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/usuarios/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0y9zbi1._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0647wox.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_usuarios_[id]_route_actions_02.fokm.js")
R.m(87015)
module.exports=R.m(87015).exports
