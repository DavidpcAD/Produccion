var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/usuarios/route.js")
R.c("server/chunks/[root-of-the-server]__0tfgiwm._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0i7wy_v.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_usuarios_route_actions_0c2q6d_.js")
R.m(80352)
module.exports=R.m(80352).exports
