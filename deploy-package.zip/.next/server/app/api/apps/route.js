var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/apps/route.js")
R.c("server/chunks/[root-of-the-server]__1175wa2._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_apps_route_actions_05x3.37.js")
R.m(86439)
module.exports=R.m(86439).exports
