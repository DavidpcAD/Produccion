var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/apps/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0h1x-mh._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_apps_[id]_route_actions_0gji5vo.js")
R.m(80141)
module.exports=R.m(80141).exports
