var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/obras/postventas/route.js")
R.c("server/chunks/[root-of-the-server]__12303lx._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_obras_postventas_route_actions_0~99-nm.js")
R.m(27565)
module.exports=R.m(27565).exports
