var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/obras/route.js")
R.c("server/chunks/[root-of-the-server]__0szkdug._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_obras_route_actions_06na-9h.js")
R.m(73410)
module.exports=R.m(73410).exports
