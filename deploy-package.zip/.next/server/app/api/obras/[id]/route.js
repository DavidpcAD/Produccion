var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/obras/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__13rtpcf._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_obras_[id]_route_actions_0vmtgi2.js")
R.m(15572)
module.exports=R.m(15572).exports
