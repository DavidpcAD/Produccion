var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/obras/[id]/bloqueo/route.js")
R.c("server/chunks/[root-of-the-server]__046qs--._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_obras_[id]_bloqueo_route_actions_0lqcd_y.js")
R.m(82332)
module.exports=R.m(82332).exports
