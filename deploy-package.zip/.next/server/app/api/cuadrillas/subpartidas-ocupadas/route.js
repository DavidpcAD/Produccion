var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cuadrillas/subpartidas-ocupadas/route.js")
R.c("server/chunks/[root-of-the-server]__0w.5lxq._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/0zjb_server_app_api_cuadrillas_subpartidas-ocupadas_route_actions_08hnnrl.js")
R.m(89542)
module.exports=R.m(89542).exports
