var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cuadrillas/route.js")
R.c("server/chunks/[root-of-the-server]__0u3-chm._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_cuadrillas_route_actions_0~p3u9r.js")
R.m(67040)
module.exports=R.m(67040).exports
