var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cuadrillas/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0~g1_j7._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0usgb4g.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_cuadrillas_[id]_route_actions_0nnfycf.js")
R.m(52730)
module.exports=R.m(52730).exports
