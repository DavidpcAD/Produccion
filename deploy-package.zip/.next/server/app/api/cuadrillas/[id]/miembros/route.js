var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cuadrillas/[id]/miembros/route.js")
R.c("server/chunks/[root-of-the-server]__12smz4u._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_cuadrillas_[id]_miembros_route_actions_08lrbp..js")
R.m(42108)
module.exports=R.m(42108).exports
