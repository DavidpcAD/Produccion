var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/dev-users/route.js")
R.c("server/chunks/[root-of-the-server]__049n78f._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_dev-users_route_actions_0-f3_qy.js")
R.m(2845)
module.exports=R.m(2845).exports
