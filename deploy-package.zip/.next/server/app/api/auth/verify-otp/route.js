var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/verify-otp/route.js")
R.c("server/chunks/[root-of-the-server]__0kpax8h._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/[root-of-the-server]__0fagu5l._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_verify-otp_route_actions_0-9_bvu.js")
R.m(76424)
module.exports=R.m(76424).exports
