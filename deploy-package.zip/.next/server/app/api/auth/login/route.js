var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__0j8mmhx._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_0zukc38.js")
R.m(74378)
module.exports=R.m(74378).exports
