var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/auditoria/route.js")
R.c("server/chunks/[root-of-the-server]__07t_mg4._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_auditoria_route_actions_0p-ni3-.js")
R.m(91055)
module.exports=R.m(91055).exports
