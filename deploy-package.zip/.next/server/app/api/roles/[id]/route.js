var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/roles/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__02xjcas._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_roles_[id]_route_actions_07._knu.js")
R.m(93379)
module.exports=R.m(93379).exports
