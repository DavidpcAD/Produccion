var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/roles/[id]/usuarios/route.js")
R.c("server/chunks/[root-of-the-server]__0jivui.._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_roles_[id]_usuarios_route_actions_0_~7puz.js")
R.m(32211)
module.exports=R.m(32211).exports
