var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/roles/[id]/tipos/route.js")
R.c("server/chunks/[root-of-the-server]__00de-c3._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_roles_[id]_tipos_route_actions_0c.~0s..js")
R.m(5739)
module.exports=R.m(5739).exports
