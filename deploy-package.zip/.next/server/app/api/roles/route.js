var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/roles/route.js")
R.c("server/chunks/[root-of-the-server]__0w2tm9_._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_roles_route_actions_0pq616e.js")
R.m(4386)
module.exports=R.m(4386).exports
