var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cuentas/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0zn_-vr._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_cuentas_[id]_route_actions_0p3y9~..js")
R.m(13753)
module.exports=R.m(13753).exports
