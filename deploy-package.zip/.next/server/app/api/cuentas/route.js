var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cuentas/route.js")
R.c("server/chunks/[root-of-the-server]__0~yxjf-._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_cuentas_route_actions_0q-x50i.js")
R.m(11517)
module.exports=R.m(11517).exports
