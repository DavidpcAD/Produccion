var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/encargados-partida/route.js")
R.c("server/chunks/[root-of-the-server]__0-we7xt._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_encargados-partida_route_actions_10mskhs.js")
R.m(74073)
module.exports=R.m(74073).exports
