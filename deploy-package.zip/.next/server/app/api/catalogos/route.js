var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/catalogos/route.js")
R.c("server/chunks/[root-of-the-server]__0lmi9~i._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_catalogos_route_actions_097j5p8.js")
R.m(23406)
module.exports=R.m(23406).exports
