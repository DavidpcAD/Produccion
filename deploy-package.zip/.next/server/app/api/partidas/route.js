var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/partidas/route.js")
R.c("server/chunks/[root-of-the-server]__0ilhtyp._.js")
R.c("server/chunks/[root-of-the-server]__0nglzhr._.js")
R.c("server/chunks/_0e6t6te._.js")
R.c("server/chunks/_next-internal_server_app_api_partidas_route_actions_125a.m_.js")
R.m(81424)
module.exports=R.m(81424).exports
