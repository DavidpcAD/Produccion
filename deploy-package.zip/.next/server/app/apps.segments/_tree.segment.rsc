:HL["/_next/static/chunks/0s72upx-k_2ea.css","style"]
:HL["/_next/static/media/ce62453a442c7f35-s.p.0333ktddfbsxy.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"(protected)","param":null,"prefetchHints":0,"slots":{"children":{"name":"apps","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"r-hS5RZJ_YMGw7yLZvjar"}
