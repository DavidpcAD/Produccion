module.exports=[40443,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_partidas_route_actions_125a.m_.js.map