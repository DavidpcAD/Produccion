module.exports=[58317,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_roles_page_actions_0mw.jvw.js.map