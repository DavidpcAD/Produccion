module.exports=[85827,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_obras_page_actions_0f4ypxo.js.map