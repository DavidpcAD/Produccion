module.exports=[61802,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_partidas_page_actions_0bnmtvz.js.map