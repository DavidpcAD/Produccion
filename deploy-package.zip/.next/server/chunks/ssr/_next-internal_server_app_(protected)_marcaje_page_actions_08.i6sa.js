module.exports=[38575,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_marcaje_page_actions_08.i6sa.js.map