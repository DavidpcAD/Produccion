module.exports=[55863,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_cuadrillas_%5Bid%5D_page_actions_004gyjo.js.map