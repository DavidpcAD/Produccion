module.exports=[38481,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_usuarios_nuevo_page_actions_0.x.11w.js.map