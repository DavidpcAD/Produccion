module.exports=[14722,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_proyectos_page_actions_0kxl9ob.js.map