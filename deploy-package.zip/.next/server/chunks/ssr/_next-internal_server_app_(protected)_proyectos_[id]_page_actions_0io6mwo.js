module.exports=[32976,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_proyectos_%5Bid%5D_page_actions_0io6mwo.js.map