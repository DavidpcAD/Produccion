module.exports=[61541,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_usuarios_page_actions_0yjs3i3.js.map