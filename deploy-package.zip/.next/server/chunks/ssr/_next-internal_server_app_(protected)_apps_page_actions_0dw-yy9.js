module.exports=[95440,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_apps_page_actions_0dw-yy9.js.map