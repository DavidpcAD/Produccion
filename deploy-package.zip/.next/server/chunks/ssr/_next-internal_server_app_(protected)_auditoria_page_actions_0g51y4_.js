module.exports=[40341,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_auditoria_page_actions_0g51y4_.js.map