module.exports=[46123,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_usuarios_%5Bid%5D_page_actions_08y6e5j.js.map