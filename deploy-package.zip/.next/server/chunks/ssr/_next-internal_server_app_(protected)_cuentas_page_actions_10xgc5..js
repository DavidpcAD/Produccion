module.exports=[35225,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_cuentas_page_actions_10xgc5..js.map