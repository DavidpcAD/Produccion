module.exports=[11685,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_cuadrillas_page_actions_0~3xrz~.js.map