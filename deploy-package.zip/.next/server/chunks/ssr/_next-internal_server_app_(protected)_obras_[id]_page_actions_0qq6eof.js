module.exports=[73852,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_obras_%5Bid%5D_page_actions_0qq6eof.js.map