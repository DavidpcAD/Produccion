module.exports=[26873,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bc_tasks_route_actions_0ljhwmm.js.map