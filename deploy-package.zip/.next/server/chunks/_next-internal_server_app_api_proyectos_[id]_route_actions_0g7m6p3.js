module.exports=[66047,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proyectos_%5Bid%5D_route_actions_0g7m6p3.js.map