module.exports=[14299,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_obras_postventas_route_actions_0~99-nm.js.map