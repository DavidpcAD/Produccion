module.exports=[18622,(e,r,o)=>{r.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,r,o)=>{r.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,r,o)=>{r.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,r,o)=>{r.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},24361,(e,r,o)=>{r.exports=e.x("util",()=>require("util"))},88947,(e,r,o)=>{r.exports=e.x("stream",()=>require("stream"))},874,(e,r,o)=>{r.exports=e.x("buffer",()=>require("buffer"))},54799,(e,r,o)=>{r.exports=e.x("crypto",()=>require("crypto"))},93695,(e,r,o)=>{r.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},59100,(e,r,o)=>{r.exports=e.x("mssql-175261ed43fbf286",()=>require("mssql-175261ed43fbf286"))},69846,e=>{"use strict";var r=e.i(59100);e.s(["sql",()=>r.default])},76636,81579,87683,e=>{"use strict";var r=e.i(59100);let o={server:process.env.DB_SERVER||process.env.SQL_SERVER,database:process.env.DB_NAME||process.env.DB_DATABASE||process.env.SQL_DATABASE,user:process.env.DB_USER||process.env.SQL_USER,password:process.env.DB_PASSWORD||process.env.SQL_PASSWORD,port:parseInt(process.env.DB_PORT||"1433"),connectionTimeout:6e4,requestTimeout:45e3,options:{encrypt:!0,trustServerCertificate:!1},pool:{max:10,min:0,idleTimeoutMillis:3e4}},a=null;async function i(){if(a&&a.connected)return a;if(a&&!a.connected){try{await a.close()}catch{}a=null}return a=await r.default.connect(o)}e.s(["getDb",0,i],81579);var t=e.i(69846);let s={1:4,2:1,3:2,4:2,5:1,6:1},n={superadministrador:4,"super administrador":4,"super admin":4,administrador:4,"ingeniero residente":2,"jefe de cuadrillas":2,"maestro de obras":1,proveeduría:1,proveeduria:1,"facturador bodega":1};function d(e){let r=0;for(let o of e){let e=o.nombre?n[o.nombre.trim().toLowerCase()]:void 0,a=s[o.idRol],i=e??a??1;i>r&&(r=i)}return r}async function l(e){let r=await i(),o=(await r.request().input("login",t.sql.NVarChar,e).query(`
      SELECT TOP 1
        u.idUsuario, u.idColaborador, u.username, u.passwordHash,
        c.cedula, c.calcNombreCompleto AS nombre,
        COALESCE(NULLIF(u.telefono, ''), c.telefono) AS telefono,
        c.esActivo
      FROM dbo.Usuario u
      JOIN dbo.Colaborador c ON c.idColaborador = u.idColaborador
      WHERE u.username = @login OR c.cedula = @login
    `)).recordset[0];return o?{idUsuario:o.idUsuario,idColaborador:o.idColaborador,username:o.username,passwordHash:o.passwordHash,cedula:o.cedula,nombre:(o.nombre??"").trim(),telefono:o.telefono,esActivo:!!o.esActivo}:null}async function u(e){let r=await i();return(await r.request().input("idUsuario",t.sql.Int,e).query(`
      SELECT r.idRol, r.nombre
      FROM dbo.UsuarioRol ur
      JOIN dbo.Rol r ON r.idRol = ur.idRol
      WHERE ur.idUsuario = @idUsuario
    `)).recordset.map(e=>({idRol:e.idRol,nombre:e.nombre}))}async function c(e){let r=await i(),o=(await r.request().input("idUsuario",t.sql.Int,e).query(`
      SELECT u.idUsuario, u.idColaborador, u.username, c.cedula,
             c.calcNombreCompleto AS nombre
      FROM dbo.Usuario u
      JOIN dbo.Colaborador c ON c.idColaborador = u.idColaborador
      WHERE u.idUsuario = @idUsuario
    `)).recordset[0];if(!o)return null;let a=await u(e);return{idCol:o.idColaborador,idUsuario:o.idUsuario,cedula:o.cedula??o.username,nombre:(o.nombre??o.username??"").trim(),roles:a.map(e=>e.idRol),nivelAdmin:d(a)}}e.s(["ROLE_LEVEL_BY_ID",0,s,"computeNivelAdmin",0,d],87683),e.s(["buildSessionPayload",0,c,"findUsuarioByLogin",0,l,"getRolesDeUsuario",0,u],76636)},10839,e=>{"use strict";var r=e.i(81579),o=e.i(69846);async function a(e){try{let a=await (0,r.getDb)();if(null===e.idColAccion)return;{let r=await a.request().input("id",o.sql.Int,e.idColAccion).query("SELECT 1 AS found FROM dbo.Colaborador WHERE idColaborador = @id");if(0===r.recordset.length)return}await a.request().input("idColAccion",o.sql.Int,e.idColAccion).input("accion",o.sql.NVarChar,e.accion).input("entidad",o.sql.NVarChar,e.entidad??null).input("idEntidad",o.sql.Int,e.idEntidad??null).input("detallePrevio",o.sql.NVarChar,e.detallePrevio?JSON.stringify(e.detallePrevio):null).input("detalleNuevo",o.sql.NVarChar,e.detalleNuevo?JSON.stringify(e.detalleNuevo):null).input("ip",o.sql.NVarChar,e.ip??null).query(`
        INSERT INTO UsuarioAuditLog
          (IDColAccion, Accion, Entidad, IDEntidad, DetallePrevio, DetalleNuevo, IP)
        VALUES
          (@idColAccion, @accion, @entidad, @idEntidad, @detallePrevio, @detalleNuevo, @ip)
      `)}catch(e){console.error("Audit log error:",e)}}e.s(["logAudit",0,a])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0y9zbi1._.js.map