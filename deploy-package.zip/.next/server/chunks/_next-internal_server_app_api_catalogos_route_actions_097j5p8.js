module.exports=[85920,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_catalogos_route_actions_097j5p8.js.map