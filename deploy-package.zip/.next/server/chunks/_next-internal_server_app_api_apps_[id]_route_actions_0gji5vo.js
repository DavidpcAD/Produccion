module.exports=[46474,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_apps_%5Bid%5D_route_actions_0gji5vo.js.map