module.exports=[94214,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bc_inventory-groups_route_actions_0_8pw7m.js.map