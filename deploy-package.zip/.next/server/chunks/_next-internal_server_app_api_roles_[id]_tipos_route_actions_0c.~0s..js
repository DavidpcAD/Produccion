module.exports=[48820,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_roles_%5Bid%5D_tipos_route_actions_0c.~0s..js.map