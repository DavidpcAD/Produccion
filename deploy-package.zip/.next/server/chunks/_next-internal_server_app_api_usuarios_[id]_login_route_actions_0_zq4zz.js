module.exports=[72058,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_usuarios_%5Bid%5D_login_route_actions_0_zq4zz.js.map