module.exports=[27330,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_usuarios_%5Bid%5D_roles_route_actions_0oyapy3.js.map