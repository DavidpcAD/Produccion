module.exports=[32121,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proyectos_route_actions_0.1t~f8.js.map