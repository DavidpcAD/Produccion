module.exports=[81059,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cuadrillas_%5Bid%5D_miembros_route_actions_08lrbp..js.map