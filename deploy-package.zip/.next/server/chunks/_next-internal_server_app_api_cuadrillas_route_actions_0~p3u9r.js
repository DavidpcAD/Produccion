module.exports=[32659,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cuadrillas_route_actions_0~p3u9r.js.map