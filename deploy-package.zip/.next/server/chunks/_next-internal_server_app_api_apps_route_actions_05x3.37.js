module.exports=[38297,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_apps_route_actions_05x3.37.js.map