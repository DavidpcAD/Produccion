module.exports=[4227,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cuadrillas_%5Bid%5D_route_actions_0nnfycf.js.map