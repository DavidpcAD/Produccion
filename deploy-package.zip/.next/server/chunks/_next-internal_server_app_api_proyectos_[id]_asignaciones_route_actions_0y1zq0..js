module.exports=[50884,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proyectos_%5Bid%5D_asignaciones_route_actions_0y1zq0..js.map