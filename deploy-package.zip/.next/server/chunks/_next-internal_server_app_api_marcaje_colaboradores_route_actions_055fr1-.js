module.exports=[34124,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_marcaje_colaboradores_route_actions_055fr1-.js.map