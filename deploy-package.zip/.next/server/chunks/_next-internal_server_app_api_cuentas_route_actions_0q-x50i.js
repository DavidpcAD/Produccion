module.exports=[38589,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cuentas_route_actions_0q-x50i.js.map