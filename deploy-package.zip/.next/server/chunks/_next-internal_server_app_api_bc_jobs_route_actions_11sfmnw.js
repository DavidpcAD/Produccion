module.exports=[11126,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bc_jobs_route_actions_11sfmnw.js.map