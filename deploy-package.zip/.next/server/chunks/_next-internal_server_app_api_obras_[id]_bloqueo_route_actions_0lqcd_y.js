module.exports=[25384,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_obras_%5Bid%5D_bloqueo_route_actions_0lqcd_y.js.map