module.exports=[84718,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_subpartidas_route_actions_053le56.js.map