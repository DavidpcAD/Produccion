module.exports=[12935,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_obras_%5Bid%5D_route_actions_0vmtgi2.js.map