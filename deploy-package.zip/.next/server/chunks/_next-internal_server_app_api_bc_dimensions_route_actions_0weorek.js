module.exports=[24910,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bc_dimensions_route_actions_0weorek.js.map