module.exports=[29126,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_usuarios_%5Bid%5D_marcaje_route_actions_0nm652c.js.map