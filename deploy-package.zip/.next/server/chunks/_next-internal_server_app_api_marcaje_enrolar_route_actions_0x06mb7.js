module.exports=[75405,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_marcaje_enrolar_route_actions_0x06mb7.js.map