module.exports=[84656,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_obras_route_actions_06na-9h.js.map