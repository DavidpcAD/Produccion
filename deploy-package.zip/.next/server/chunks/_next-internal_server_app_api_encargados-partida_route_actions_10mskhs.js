module.exports=[98617,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_encargados-partida_route_actions_10mskhs.js.map