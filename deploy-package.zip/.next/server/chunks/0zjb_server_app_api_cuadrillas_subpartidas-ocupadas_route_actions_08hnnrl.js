module.exports=[88801,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_cuadrillas_subpartidas-ocupadas_route_actions_08hnnrl.js.map