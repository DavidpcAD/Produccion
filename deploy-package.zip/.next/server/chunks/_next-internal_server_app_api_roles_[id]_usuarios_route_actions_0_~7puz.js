module.exports=[10210,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_roles_%5Bid%5D_usuarios_route_actions_0_~7puz.js.map